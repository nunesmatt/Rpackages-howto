# test script for the 3 packages for the course:
#
# roots
# secondpkg
# mattpkg

# Will be very similar to the examples sections of the packages - if the R CMD check fails on the packages,
# this script will also fail, and if the package passes all the checks, then this will work, but you really
# mainly want to check the dependencies.

# load libraries.  Note: you can get load dependent packages automatically by adding a library()
# command to the zzz.R files of packages.

library(roots)
library(secondpkg)
library(mattpkg)

#the original first package.
#testing roots.....

a<-scan(n=1)
a<-abs(a)
#the fifth root of a is:

cat(fifthroot(a),"\n")

#some complex setup and S3 practice
#testing secondpkg.....

z<-complex(re=2,im=2)
r<-nthroot(z,5,all=TRUE)

cat(r,"\n")

#Amateur polygon constructibility test which came up in a fellow researcher's lit review. 
#testing mattpkg.....

#The 17-gon is constructible using compasses and a straight edge.  Here it is.  
#The function has dependency on roots plot generics and class.

checkngon(17,plot.it=T)

graphics.off()

cat("Well done, your package works.\n\n Matt.\n\n")

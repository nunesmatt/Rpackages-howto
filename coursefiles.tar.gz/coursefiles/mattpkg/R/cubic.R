cubic <-
function(coef){

n<-length(coef)
if(n>4){
	stop("there can only be a maximum of 4 coefficients for a 
	cubic!!\n")
}

if(n<4){
coef<-c(coef,rep(0,times=4-n))
}

x<-coef

class(x)<-"cubic"

x
}


plotngon <-
function(n,r=1,...){

# the radius of the ngon

tmp<-r*rootsofunity(n)

#tmp should be of class rou.
plot(tmp,lty=2)

polygon(tmp,...)

}


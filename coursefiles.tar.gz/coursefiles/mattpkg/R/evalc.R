evalc <-
function(x,a){

vals<-NULL
for(i in 1:length(a)){
	vals[i]<-sum(unclass(x)*a[i]^(3:0))
}

vals
}


fermatp <-
function(n){
2^(2^n)+1
}


.First.lib <-function(lib,pkg){

ver <- read.dcf(file.path(lib, pkg, "DESCRIPTION"), "Version")

ver <- as.character(ver)	

#library.dynam("mattpkg",pkg,lib)
     
cat("mattpkg", ver, "loaded\n")

}
     

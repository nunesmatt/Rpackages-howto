#include<math.h>
#include<stdio.h>
#include<stdlib.h>

int isPowerOfTwo (int x)
{
  return ((x != 0) && !(x & (x - 1)));
}
  

int fermatp(int *n){

return( (int) pow(2,(int) pow(2,*n) )+1);
}

void constrngon(int *n,int *bool,int *counts){

int i;
int rem=0,grem=0;
int tmp,tmp2,x,p;
double prod=1;
int s=0;

/* the first 5 fermat numbers are non composite */
int fermats[]={3,5,17,257,65537};

int fermatp();
int isPowerOfTwo();

for(i=0;i<5;i++){
	x=*n;
	p=*(fermats+i);
	rem=0;
	while(rem==0){
		rem=x%p;
		if(rem==0){
			x/=p;
			*(counts+i)+=1;
		}	
	}
}
printf("checked first 5 Fermat prime factors...\n");

tmp=0;
for(i=0;i<5;i++){
	tmp2=*(counts+i)>1 ? 1 : 0;
	tmp+=tmp2;
	prod*= pow(*(fermats+i),*(counts+i));
	s+=*(counts+i);
}
p=(int) prod;

if((tmp>0)){
	*bool=0;
	printf("%d: %d\n",*n,*bool);
	return;
}
else{
	grem=*n/p;
	tmp=isPowerOfTwo(grem);
	if( (grem!=1) & (tmp==0) ){
		*bool=0;
		return;
	}
	else{
		*(counts+5)=(int) log2(grem);
	}
}

}

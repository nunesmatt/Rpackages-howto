rootsofunity <-
function(n){

segments<-(1:n)*(2*pi/n)

roots<-polartoxy(1,segments)

class(roots)<-"rou"
roots
}


polartoxy <-
function(r,theta){

z<-complex(mod=r,arg=theta)

}


plot.rou <-
function(x,...){

xtmp<-x
class(xtmp)<-"roots"
plot(xtmp,addline=FALSE,...)

#use polygon plot instead of symbols(circles) due to spacing...

tmp<-rootsofunity(100)
polygon(tmp,lty=2)




}


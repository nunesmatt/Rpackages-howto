xytopolar <-
function(z){

r<-Mod(z)

th=Arg(z)

return(cbind(r,th))
}


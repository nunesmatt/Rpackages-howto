plot.roots <-
function(x,addline=TRUE,...){

#will in effect do plot.complex

mr<-max(abs(Re(x)))*1.1
mi<-max(abs(Im(x)))*1.1


plot.default(x,xlim=c(-mr,mr),ylim=c(-mi,mi),...)
segments(0,0,Re(x),Im(x))
if(addline){
	abline(h=0,col=3,lty=3)
}

}


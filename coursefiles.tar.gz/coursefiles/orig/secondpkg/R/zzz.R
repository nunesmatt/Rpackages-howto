.First.lib <-function(lib,pkg){

ver <- read.dcf(file.path(lib, pkg, "DESCRIPTION"), "Version")

ver <- as.character(ver)	
     
cat("secondpkg", ver, "loaded\n")

}
     

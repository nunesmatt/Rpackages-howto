fifthroot <- function(x)
{
   out <- .C("fifrt",as.double(x),ans=double(1),PACKAGE="roots")
   return(out$ans)
}

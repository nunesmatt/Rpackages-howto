fourthroot <- function(x)
{
   if (x<0)
      stop("negative arguments not allowed")
   ans <- 0
   out <- .Fortran("fthrt",as.double(x),ans=as.double(ans),PACKAGE="roots")

   return(out$ans)
}

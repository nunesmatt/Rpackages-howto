.First.lib <-function(lib,pkg){

ver <- read.dcf(file.path(lib, pkg, "DESCRIPTION"), "Version")

ver <- as.character(ver)	

library.dynam("roots",pkg,lib)
     
cat("roots", ver, "loaded\n")

}
     

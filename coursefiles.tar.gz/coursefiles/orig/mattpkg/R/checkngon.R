checkngon <-
function(n,plot.it=FALSE){

tmp<-.C("constrngon",as.integer(n),as.integer(1),as.integer(rep(0,6)),
		PACKAGE="mattpkg")
valid<-tmp[[2]]


if(plot.it){
	plotngon(n)
}
powers<-tmp[[3]]
names(powers)<-c(paste("F_",0:4,sep=""),"2^k")

return(list(valid=(valid==1),powers=powers))
}


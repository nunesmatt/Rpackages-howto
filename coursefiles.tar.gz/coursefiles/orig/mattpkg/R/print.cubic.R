print.cubic <-
function(x,...){

coef<-x
q<-which(coef!=0)
nq<-length(q)
terms<-c("x^3","x^2","x","")
out<-NULL
for(i in 1:nq){
	nm<-paste(round(coef[q[i]],3),terms[q[i]],sep="")
	if(i<nq){
		nm<-paste(nm,"+ ")
	}
	out<-paste(out,nm,sep="")
}	
cat(out,"\n")
}


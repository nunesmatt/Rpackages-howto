     #include <math.h>
  
     void fifrt(double *x, double *ans)
     {   
  
        *ans=pow(*x,0.2);
  
     }   

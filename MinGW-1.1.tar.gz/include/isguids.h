#ifndef _ISGUID_H
#define _ISGUID_H
#ifdef __cplusplus
extern "C" {
#endif
extern const GUID CLSID_InternetShortcut;
extern const GUID IID_IUniformResourceLocator;
#ifdef __cplusplus
}
#endif
#endif

A set of tools which will suffice to build and test R for Windows.

cat cp cut date diff echo egrep expr grep ls mkdir mv rm sed sh touch

These are extracted from the cygwin collection
(http://sources.redhat.com/cygwin and several mirrors).

make is compiled from the sources, altered to use sh.exe in the path 
if this exists (rather than /bin/sh.exe).

tar is compiled from the sources, altered to accept Windows drives
in the path specification, and to give reasonable file permissions
(at least 644 for files and 755 for dirs).

zip, unzip from the Info-ZIP collection.

makeinfo and texindex compiled from the texinfo-4.6 sources.

tidy, compiled from its sources.

gzip, compiled from source.


Extras
======

Also included are sort (which is needed by Rd2dvi.sh), basename, comm,
find, gawk and wc (which used to be needed), as well as cmp, ln, od,
rmdir, tr and uniq which are needed by some configure scripts.

md5sum can be used to create checksums, or check checksum files.

pedump is very useful for examining DLLs for imports and exports.


Sources
=======

The current version of this archive will be at

http://www.stats.ox.ac.uk/pub/Rtools/tools.zip

and that directory also contains all the sources for the GPL-ed 
components included here.
